//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DNgt4UOR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/munag/OneDrive/Desktop/Binduswethaimages/BinduSwethas Portofolio/pasluribinduswetha-main/pasluribinduswetha-main/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CmXw4PRf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CmXw4PRf.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/munag/OneDrive/Desktop/Binduswethaimages/BinduSwethas Portofolio/pasluribinduswetha-main/pasluribinduswetha-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BlVDmni6.js"]
	}
} });
//#endregion
export { tsrStartManifest };
