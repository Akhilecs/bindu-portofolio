globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-19T04:57:36.461Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/bindu-BJtO-CwT.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1badf-69zy5JOvAcoxGtBulrsBnvks6Go\"",
		"mtime": "2026-08-19T07:44:27.961Z",
		"size": 113375,
		"path": "../public/assets/bindu-BJtO-CwT.jpeg"
	},
	"/assets/amaravathispoken-DS5tHTpG.jpeg": {
		"type": "image/jpeg",
		"etag": "\"28413-R/942DkI5lVSfuNJYsAle7gPHvo\"",
		"mtime": "2026-08-19T07:44:27.959Z",
		"size": 164883,
		"path": "../public/assets/amaravathispoken-DS5tHTpG.jpeg"
	},
	"/assets/appeciation-Cz6rZnhv.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2f7ff-uuzoySpxWJbxd1Hr4jpXFu/rBjw\"",
		"mtime": "2026-08-19T07:44:27.960Z",
		"size": 194559,
		"path": "../public/assets/appeciation-Cz6rZnhv.jpeg"
	},
	"/assets/g2-C3FUGWe2.jpg": {
		"type": "image/jpeg",
		"etag": "\"2b1a5-N+DKeVCZ+HIKGEOZTmKwP/iMuks\"",
		"mtime": "2026-08-19T07:44:27.966Z",
		"size": 176549,
		"path": "../public/assets/g2-C3FUGWe2.jpg"
	},
	"/assets/g3-Bqg3eTfs.jpg": {
		"type": "image/jpeg",
		"etag": "\"1a63c-gwFK9Vy26lLZn0eF5Uo7DUMf/b4\"",
		"mtime": "2026-08-19T07:44:27.967Z",
		"size": 108092,
		"path": "../public/assets/g3-Bqg3eTfs.jpg"
	},
	"/assets/explain-8WN8lOb2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"27eb0-jnTyJMSY150M9EPL2K54g9AkhTA\"",
		"mtime": "2026-08-19T07:44:27.963Z",
		"size": 163504,
		"path": "../public/assets/explain-8WN8lOb2.jpeg"
	},
	"/assets/g1-Bb44Kbzp.jpg": {
		"type": "image/jpeg",
		"etag": "\"1b068-R9rD7tG+pLyLW0iT1nEpKQDv6p8\"",
		"mtime": "2026-08-19T07:44:27.965Z",
		"size": 110696,
		"path": "../public/assets/g1-Bb44Kbzp.jpg"
	},
	"/assets/index-CmXw4PRf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5d08f-wzId6QoAA+JuQpehM9aE3/nNikE\"",
		"mtime": "2026-08-19T07:44:27.952Z",
		"size": 381071,
		"path": "../public/assets/index-CmXw4PRf.js"
	},
	"/assets/g4-2m9UUS5M.jpg": {
		"type": "image/jpeg",
		"etag": "\"199e8-RiKSWcWHXlOGeDJ6zvXezpVQDg4\"",
		"mtime": "2026-08-19T07:44:27.968Z",
		"size": 104936,
		"path": "../public/assets/g4-2m9UUS5M.jpg"
	},
	"/assets/g6-tT2Ze3ju.jpg": {
		"type": "image/jpeg",
		"etag": "\"129e8-UOMb10PU4lzTX2eA7QNWDTtsaW8\"",
		"mtime": "2026-08-19T07:44:27.969Z",
		"size": 76264,
		"path": "../public/assets/g6-tT2Ze3ju.jpg"
	},
	"/assets/routes-BlVDmni6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b0b6-lrlCVzJNtoyDe8ZA+55QezVxx+I\"",
		"mtime": "2026-08-19T07:44:27.954Z",
		"size": 241846,
		"path": "../public/assets/routes-BlVDmni6.js"
	},
	"/assets/judging-CkYZfxYJ.jpeg": {
		"type": "image/jpeg",
		"etag": "\"29c60-eyVtanRjr7gcmFIxQthBXGM7bgk\"",
		"mtime": "2026-08-19T07:44:27.971Z",
		"size": 171104,
		"path": "../public/assets/judging-CkYZfxYJ.jpeg"
	},
	"/assets/styles-CQ1sdXL3.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14e3a-K7hnerBrA+Be/v7J0plVAyuteSk\"",
		"mtime": "2026-08-19T07:44:27.974Z",
		"size": 85562,
		"path": "../public/assets/styles-CQ1sdXL3.css"
	},
	"/assets/research-D0jP4cmv.jpeg": {
		"type": "image/jpeg",
		"etag": "\"7457f-gDRcjynazLDqKit93GsRkQ+ds0I\"",
		"mtime": "2026-08-19T07:44:27.972Z",
		"size": 476543,
		"path": "../public/assets/research-D0jP4cmv.jpeg"
	},
	"/assets/tp-7sCm3I_2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"21bf8-1TKZC6PdTFGmet8yUmFLxOG7wSM\"",
		"mtime": "2026-08-19T07:44:27.977Z",
		"size": 138232,
		"path": "../public/assets/tp-7sCm3I_2.jpeg"
	},
	"/assets/tablemeet-4nzr4gup.jpeg": {
		"type": "image/jpeg",
		"etag": "\"2dec6-53Xgf/jPlcgC3vEUryGNsfECGLc\"",
		"mtime": "2026-08-19T07:44:27.975Z",
		"size": 188102,
		"path": "../public/assets/tablemeet-4nzr4gup.jpeg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_0hG4ii = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_0hG4ii
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
