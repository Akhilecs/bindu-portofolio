import { r as __toESM } from "../_runtime.mjs";
import { a as AnimatePresence, n as useSpring, o as performance_default, r as useScroll, t as useInView } from "../_libs/framer-motion+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as motion } from "../_libs/motion.mjs";
import { A as Award, C as FileText, D as Briefcase, E as ChartLine, M as ArrowRight, N as ArrowLeft, O as BrainCircuit, S as FingerprintPattern, T as Cpu, _ as Library, a as Star, b as Handshake, c as ShieldAlert, d as Presentation, f as Menu, g as Lightbulb, h as Linkedin, i as Target, j as AudioWaveform, k as BookOpen, l as Send, m as Mail, n as Users, o as Sigma, p as MapPin, r as Trophy, s as ShieldCheck, t as X, u as Search, v as Landmark, w as ExternalLink, x as GraduationCap, y as HeartPulse } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as useEmblaCarousel } from "../_libs/embla-carousel-react+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D-jecnH3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var links = [
	{
		id: "about",
		label: "About"
	},
	{
		id: "research",
		label: "Research"
	},
	{
		id: "publications",
		label: "Publications"
	},
	{
		id: "patents",
		label: "Patents"
	},
	{
		id: "journey",
		label: "Journey"
	},
	{
		id: "gallery",
		label: "Gallery"
	},
	{
		id: "awards",
		label: "Awards"
	},
	{
		id: "contact",
		label: "Contact"
	}
];
function Nav() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [active, setActive] = (0, import_react.useState)("about");
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		const observer = new IntersectionObserver((entries) => {
			entries.forEach((e) => {
				if (e.isIntersecting) setActive(e.target.id);
			});
		}, { rootMargin: "-45% 0px -50% 0px" });
		links.forEach((l) => {
			const el = document.getElementById(l.id);
			if (el) observer.observe(el);
		});
		return () => observer.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `fixed inset-x-0 top-0 z-50 transition-all duration-300 ${scrolled ? "border-b border-border bg-background/85 backdrop-blur-xl" : "bg-transparent"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "mx-auto flex max-w-6xl items-center justify-between px-5 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-10 w-10 place-items-center rounded-xl font-display text-sm font-bold text-primary-foreground",
						style: { background: "var(--gradient-primary)" },
						children: "BS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "leading-tight",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-bold",
							children: "Dr. P. Bindu Swetha"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-[10px] uppercase tracking-[0.18em] text-muted-foreground",
							children: "Professor · Researcher · Innovator"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden items-center gap-1 lg:flex",
					children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `#${l.id}`,
						className: "relative rounded-full px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground",
						children: [active === l.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
							layoutId: "nav-pill",
							className: "absolute inset-0 rounded-full bg-accent",
							transition: {
								type: "spring",
								stiffness: 380,
								damping: 30
							}
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `relative ${active === l.id ? "text-accent-foreground" : ""}`,
							children: l.label
						})]
					}, l.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						className: "hidden sm:inline-flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contact",
							children: "Collaborate"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Toggle menu",
						onClick: () => setOpen((o) => !o),
						className: "grid h-10 w-10 place-items-center rounded-xl border border-border lg:hidden",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
			initial: false,
			animate: {
				height: open ? "auto" : 0,
				opacity: open ? 1 : 0
			},
			className: "overflow-hidden border-t border-border bg-background lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-1 px-5 py-4",
				children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `#${l.id}`,
					onClick: () => setOpen(false),
					className: "rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-accent-foreground",
					children: l.label
				}, l.id))
			})
		})]
	});
}
var profile = {
	name: "Dr. Pasuluri Bindu Swetha",
	role: "Professor of ECE · Dean, Innovation (CIIE)",
	tagline: "Academician · Researcher · Innovation Ambassador",
	summary: "Passionate learner with over 17 years of experience in teaching, administration, innovation and research. Recognised as Best Innovation Ambassador, Young Innovator and Best Researcher, I build innovation ecosystems and guide students toward real-world problem solving.",
	location: "Kurnool, Andhra Pradesh, India",
	linkedin: "https://www.linkedin.com/in/dr-p-bindu-swetha-40a0951a9/",
	orcid: "0000-0003-0617-6755",
	scopus: "57208226387",
	vidwan: "335484",
	openalex: "A5123041120"
};
var stats = [
	{
		value: 51,
		suffix: "+",
		label: "Research Papers"
	},
	{
		value: 24,
		suffix: "+",
		label: "Conference Papers"
	},
	{
		value: 15,
		suffix: "",
		label: "Patents"
	},
	{
		value: 10,
		suffix: "",
		label: "Books / Chapters"
	},
	{
		value: 45,
		suffix: "+",
		label: "Certifications"
	},
	{
		value: 90,
		suffix: "+",
		label: "IIC Events"
	}
];
var orbitTopics = [
	"VLSI & Embedded Systems",
	"Vedic Arithmetic Multipliers",
	"AI & Machine Learning",
	"Signal & Image Processing",
	"Biomedical Electronics",
	"Innovation & Mentoring"
];
var researchAreas = [
	{
		title: "VLSI Design & Embedded Systems",
		icon: "Cpu",
		desc: "Advanced research in low-power architecture and optimization for modern integrated circuits.",
		keywords: [
			"Low-power CMOS",
			"GDI logic",
			"45nm design",
			"3D IC power optimisation"
		]
	},
	{
		title: "Vedic Mathematics & Multipliers",
		icon: "Sigma",
		desc: "Pioneering high-speed, low-power arithmetic multiplier architectures based on ancient Vedic algorithms.",
		keywords: [
			"Nikhilam algorithm",
			"Urdhva Tiryakbhyam",
			"Wallace-tree hybrids",
			"High-speed Arithmetic"
		]
	},
	{
		title: "Signal & Image Processing",
		icon: "AudioWaveform",
		desc: "Developing robust signal processing frameworks for next-generation telecommunication and image compression.",
		keywords: [
			"FIR filter architectures",
			"DSP for 5G/6G",
			"Image Compression",
			"Wavelet Analysis"
		]
	},
	{
		title: "Artificial Intelligence & Machine Learning",
		icon: "BrainCircuit",
		desc: "Exploring advanced AI models, deep learning architectures, and quantum-inspired reinforcement learning.",
		keywords: [
			"Quantum-inspired RL",
			"Neuromorphic computing",
			"CNN-based fusion",
			"Cancer Prediction"
		]
	},
	{
		title: "Biomedical Electronics",
		icon: "HeartPulse",
		desc: "Designing highly sensitive, low-noise instrumentation for continuous health monitoring and diagnostics.",
		keywords: [
			"ECG acquisition",
			"Low-noise instrumentation amplifiers",
			"Wearables",
			"Mental Stress Monitoring"
		]
	},
	{
		title: "Innovation & Ecosystem Mentoring",
		icon: "Lightbulb",
		desc: "Building academic innovation ecosystems and mentoring students for real-world product development.",
		keywords: [
			"IIC ecosystems",
			"EPICS course design",
			"Student product mentoring",
			"AgriTech Hackathons"
		]
	}
];
var publications = [
	{
		title: "Machine learning assigned chirp-based modulation for high mobility beyond 5G and 6G communication environments",
		venue: "IGI Global",
		year: 2026,
		type: "Chapter",
		index: "SCOPUS"
	},
	{
		title: "Digital Twin AI-Assisted Optimization of Delay-Doppler Communication Systems for Smart Industrial Automation",
		venue: "IGI Global",
		year: 2026,
		type: "Chapter",
		index: "SCOPUS"
	},
	{
		title: "Quantum inspired reinforcement learning models for adaptive decision-making in neuromorphic computational systems",
		venue: "Emerging Hybrid Models for Neuromorphic AI & Quantum Computing, IGI Global",
		year: 2026,
		type: "Chapter",
		index: "DOI 10.4018/979-8-3373-7779-7.ch006",
		link: "https://www.igi-global.com/chapter/quantum-inspired-reinforcement-learning-models-for-adaptive-decision-making-in-neuromorphic-computational-systems/404176"
	},
	{
		title: "Cyber secure IoT framework for monitoring fiber reinforced polymer composites using embedded sensors",
		venue: "STM Journals & Composites",
		year: 2026,
		type: "Journal",
		index: "ESCI / WOS"
	},
	{
		title: "CMOA-CP: Chaotic Mother Optimization for Cancer Prediction",
		venue: "ICSCSS 2026, 4th Intl. Conf. on Sustainable Computing and Smart Systems",
		year: 2026,
		type: "Conference",
		index: "SCOPUS"
	},
	{
		title: "AI-driven Enterprise solution architecture for scalable cloud-native systems",
		venue: "ICICIT 2026, 6th Intl. Conf. on Inventive Computation & Information Technologies",
		year: 2026,
		type: "Conference",
		index: "SCOPUS"
	},
	{
		title: "Combined AES-256 Encryption with MATLAB and Verilog HDL Biometric Authentication",
		venue: "IEEE ICMCSI 2026, Nepal",
		year: 2026,
		type: "Conference",
		index: "SCOPUS"
	},
	{
		title: "A Scalable 64-Bit Hybrid Multiplier Combining Vedic Arithmetic and Wallace Tree Compression",
		venue: "IEEE ICMCSI 2026, Nepal",
		year: 2026,
		type: "Conference",
		index: "SCOPUS"
	},
	{
		title: "Enhancing Lossless Image Compression through Smart Partitioning, Selective Encoding, and Wavelet Analysis",
		venue: "SSRG Intl. Journal of Electronics & Communication Engineering, 11(5)",
		year: 2024,
		type: "Journal",
		index: "SCOPUS",
		link: "https://doi.org/10.14445/23488549/IJECE-V11I5P120"
	},
	{
		title: "Analysis of Carrier to Noise Density Ratio, Satellite Visibility and Skyplot of Multiple GNSS Constellations",
		venue: "IEEE ESCI 2024, Pune",
		year: 2024,
		type: "Conference",
		index: "SCOPUS"
	},
	{
		title: "Design of high-performance GDI logic based 8-tap FIR filter at 45nm CMOS using Nikhilam Multiplier",
		venue: "IJISAE",
		year: 2022,
		type: "Journal",
		index: "SCOPUS"
	},
	{
		title: "Design of Vedic multiplier based FIR filter for signal processing applications",
		venue: "Journal of Physics: Conference Series, IOP Publishing",
		year: 2021,
		type: "Journal",
		index: "SCOPUS / SCIE"
	},
	{
		title: "Design of a low noise and low-power Instrumentation amplifier for electrocardiogram acquisition",
		venue: "Informatica Journal, 32(11)",
		year: 2021,
		type: "Journal",
		index: "WOS / SCIE"
	},
	{
		title: "VLSI Design for Efficient RSD-Based ECC Processor Using Karatsuba Algorithm",
		venue: "International Journal of Engineering & Technology (UAE)",
		year: 2018,
		type: "Journal",
		index: "SCOPUS"
	},
	{
		title: "Architecting Intelligence: A framework for scalable engineering enterprise systems",
		venue: "Vinsa Publishing",
		year: 2026,
		type: "Book"
	},
	{
		title: "Data Science and Business Analytics: Concepts, Tools and Industry Applications",
		venue: "Garuda Publishers · ISBN 978-81-685207-5-2",
		year: 2026,
		type: "Book"
	},
	{
		title: "MongoDB Essentials: From Fundamentals to Advanced Applications",
		venue: "Independently Published · ISBN 979-8276436449",
		year: 2025,
		type: "Book"
	},
	{
		title: "Foundation of VLSI Design",
		venue: "RK Publications · ISBN 978-93-48020-25-3",
		year: 2024,
		type: "Book"
	},
	{
		title: "Microprocessors & Microcontrollers",
		venue: "South Asian Academic Publications · ISBN 978-93-92153-38-9",
		year: 2022,
		type: "Book"
	},
	{
		title: "Electronic Devices and Circuits",
		venue: "MANTECH Publications · ISBN 978-81-948050-2-1",
		year: 2021,
		type: "Book"
	},
	{
		title: "An Introduction to Verilog HDL – A Beginner's Guide",
		venue: "Mahi Publications · ISBN 978-81-940137-3-0",
		year: 2019,
		type: "Book"
	}
];
var patents = [
	{
		title: "AI Assisted VLSI power optimization frameworks for 3D ICs",
		no: "202641032677",
		year: 2026,
		status: "Granted"
	},
	{
		title: "Ultra-low power wearable electronics with low leakage CMOS architecture",
		no: "202641032657",
		year: 2026,
		status: "Granted"
	},
	{
		title: "Design of portable ECG monitoring device",
		no: "484281-001",
		year: 2025,
		status: "Design Patent"
	},
	{
		title: "A novel FIR filter using GDI logic and Nikhilam-based Vedic multipliers",
		no: "202541106031",
		year: 2025,
		status: "Published"
	},
	{
		title: "Fusion of natural, medical and satellite images based on CNNs",
		no: "202541108582",
		year: 2025,
		status: "Filed"
	},
	{
		title: "Digital Multi-core SIMD Implementation for H.264/AVC Encoder",
		no: "202441018654",
		year: 2024,
		status: "Filed"
	},
	{
		title: "Crosstalk-induced delay faults in VLSI circuits using AI fan",
		no: "202441018656",
		year: 2024,
		status: "Filed"
	},
	{
		title: "Smart Billing System – Streamlining using RFID technology",
		no: "202441046363",
		year: 2024,
		status: "Filed"
	},
	{
		title: "Analog & Digital filters in biomedical applications using Nikhilam multipliers",
		no: "202241040065",
		year: 2022,
		status: "Filed"
	},
	{
		title: "Wearable device to monitor and control mental stress during isolation",
		no: "202041017124",
		year: 2020,
		status: "Filed"
	},
	{
		title: "Smart Multi-Functional Traffic Light using Organic Solar cell",
		no: "201911030347",
		year: 2019,
		status: "Filed"
	},
	{
		title: "Fuzzy Logic based Intelligent Electric Solar Dryer for Fruits",
		no: "201941032820",
		year: 2019,
		status: "Filed"
	}
];
var awards = [
	{
		title: "Inspiring Woman Educationist of the Year",
		by: "Femme Times – Super 50 Women Awards",
		year: 2026
	},
	{
		title: "Pratibha Puraskar Award (Education)",
		by: "Shalivahana Charitable Trust, Hyderabad",
		year: 2026
	},
	{
		title: "International Distinguished Academic Leader Award",
		by: "Global Edu-Conclave",
		year: 2025
	},
	{
		title: "Best Mentor Award",
		by: "Scientific International Publishing House",
		year: 2024
	},
	{
		title: "Best Women Researcher Award",
		by: "ESN Publisher, IIT Madras Research Park",
		year: 2024
	},
	{
		title: "Best Teacher Award",
		by: "Lead India, Vision Digital India",
		year: 2021
	}
];
var timeline = [
	{
		year: "2002–06",
		title: "B.Tech, ECE",
		detail: "JNTU Hyderabad, Telangana"
	},
	{
		year: "2007–25",
		title: "Assistant Professor, ECE",
		detail: "Vardhaman College of Engineering"
	},
	{
		year: "2010–12",
		title: "M.Tech, VLSI Design",
		detail: "Sathyabama Institute of Science & Technology"
	},
	{
		year: "2017–23",
		title: "Ph.D., Electronics Engineering",
		detail: "Sathyabama Institute of Science and Technology (Defended: Aug 8, 2023)"
	},
	{
		year: "2023–",
		title: "Director of Operations",
		detail: "Tech Arc business systems (Freelance)"
	},
	{
		year: "2024–",
		title: "Chief Innovation Officer",
		detail: "MAE Digital solutions (Freelance)"
	},
	{
		year: "2025–",
		title: "CIE",
		detail: "G Pullaiah College of Engineering and Technology"
	},
	{
		year: "2025–",
		title: "Professor & Dean, Innovation",
		detail: "Ravindra College of Engineering for Women (CIIE)"
	},
	{
		year: "2025–",
		title: "Innovation & Strategic Advisor",
		detail: "Lit Ruach Tech Innovations Pvt Ltd"
	}
];
var memberships = [
	"Member of IEEE",
	"Life Member of ISTE",
	"Associate Member, Institute of Engineers (IE-India)",
	"Professional member — MUACEE, MIAENG, IFERP & ERDA",
	"Distinguished Professional Fellow, DFM–ISVE Ranchi"
];
var skills = [
	"Adaptability",
	"Interpersonal Skills",
	"Critical Thinking",
	"Innovative Teaching",
	"Design & Ideas Mentoring",
	"EPICS Projects",
	"Student Development & Counselling"
];
var bindu_default = "/assets/bindu-BJtO-CwT.jpeg";
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "top",
		className: "relative overflow-hidden pt-28 pb-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 grid-backdrop" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-10 px-5 lg:grid-cols-[1.1fr_0.9fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 14
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: { duration: .5 },
					className: "inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-4 py-1.5 text-xs font-medium text-secondary-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-3.5 w-3.5 text-primary" }), "Professor | Researcher | Innovation Mentor | Academic Leader"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.h1, {
					initial: {
						opacity: 0,
						y: 22
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .65,
						delay: .08
					},
					className: "mt-6 text-5xl font-bold leading-[1.05] sm:text-6xl lg:text-7xl tracking-tight",
					children: ["Dr. P. Bindu ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gradient",
						children: "Swetha"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 18
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .6,
						delay: .14
					},
					className: "mt-6 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-primary/10 px-3 py-1 text-sm font-medium text-primary",
							children: "Artificial Intelligence & Machine Learning"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-primary/10 px-3 py-1 text-sm font-medium text-primary",
							children: "Biomedical Electronics"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-primary/10 px-3 py-1 text-sm font-medium text-primary",
							children: "Signal Processing"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-md bg-primary/10 px-3 py-1 text-sm font-medium text-primary",
							children: "Innovation & Emerging Technologies"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
					initial: {
						opacity: 0,
						y: 18
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .6,
						delay: .2
					},
					className: "mt-6 max-w-xl text-base leading-relaxed text-muted-foreground",
					children: profile.summary
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 18
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .6,
						delay: .28
					},
					className: "mt-8 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						className: "group",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#research",
							children: ["Explore My Research", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#publications",
							children: ["View Publications ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "ml-2 h-4 w-4" })]
						})
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					scale: .94
				},
				animate: {
					opacity: 1,
					scale: 1
				},
				transition: {
					duration: .8,
					delay: .15
				},
				className: "relative mx-auto aspect-square w-full max-w-[440px] px-2 mt-10 lg:mt-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-6 rounded-full opacity-70 blur-2xl",
						style: { background: "radial-gradient(circle at 50% 40%, oklch(0.88 0.07 285), transparent 65%)" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "orbit-ring absolute inset-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-4 rounded-full border border-dashed border-primary/25" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-14 rounded-full border border-primary/15" }),
							orbitTopics.map((topic, i) => {
								const angle = i / orbitTopics.length * Math.PI * 2 - Math.PI / 2;
								const r = 45;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute",
									style: {
										left: `${50 + r * Math.cos(angle)}%`,
										top: `${50 + r * Math.sin(angle)}%`,
										transform: "translate(-50%, -50%)"
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "orbit-counter",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "whitespace-nowrap rounded-full border border-border bg-card px-3 py-1.5 text-[10px] font-semibold shadow-[var(--shadow-soft)] sm:text-xs",
											children: topic
										})
									})
								}, topic);
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "float-soft absolute inset-[18%] overflow-hidden rounded-full border border-border bg-card shadow-[var(--shadow-float)]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: bindu_default,
							alt: "Dr. Pasuluri Bindu Swetha, Professor of ECE and Dean of Innovation",
							className: "h-full w-full object-cover object-center"
						})
					})
				]
			})]
		})]
	});
}
function Counter({ value, suffix }) {
	const ref = (0, import_react.useRef)(null);
	const inView = useInView(ref, {
		once: true,
		margin: "-60px"
	});
	const [n, setN] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!inView) return;
		let raf = 0;
		const start = performance_default.now();
		const dur = 1400;
		const tick = (t) => {
			const p = Math.min((t - start) / dur, 1);
			setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
			if (p < 1) raf = requestAnimationFrame(tick);
		};
		raf = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(raf);
	}, [inView, value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		ref,
		className: "text-3xl font-bold text-gradient sm:text-4xl",
		children: [n, suffix]
	});
}
function Stats() {
	const primaryStats = stats.filter((s) => [
		"Research Papers",
		"Patents",
		"Books / Chapters",
		"Conference Papers"
	].includes(s.label)).sort((a, b) => {
		const order = [
			"Research Papers",
			"Patents",
			"Books / Chapters",
			"Conference Papers"
		];
		return order.indexOf(a.label) - order.indexOf(b.label);
	});
	const secondaryStats = stats.filter((s) => ![
		"Research Papers",
		"Patents",
		"Books / Chapters",
		"Conference Papers"
	].includes(s.label));
	const formatLabel = (label) => {
		if (label === "Research Papers") return "Research Publications";
		if (label === "Conference Papers") return "Conference Contributions";
		return label;
	};
	const iconMap = {
		"Research Papers": FileText,
		"Patents": ShieldCheck,
		"Books / Chapters": BookOpen,
		"Conference Papers": Presentation,
		"Certifications": Award,
		"IIC Events": Star
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-6xl px-5 py-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-card p-8 sm:p-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-y-10 sm:grid-cols-4 divide-x divide-border/50",
				children: primaryStats.map((s, i) => {
					const Icon = iconMap[s.label];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center px-4 flex flex-col items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-center gap-3",
							children: [Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6 text-primary/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, {
								value: s.value,
								suffix: s.suffix
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-medium text-muted-foreground",
							children: formatLabel(s.label)
						})]
					}, s.label);
				})
			}), secondaryStats.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 pt-8 border-t border-border/50 flex flex-wrap justify-center gap-8",
				children: secondaryStats.map((s) => {
					const Icon = iconMap[s.label];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center flex flex-col items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-center gap-2",
							children: [Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-primary/60" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xl font-bold text-foreground/80",
								children: [s.value, s.suffix]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs font-medium text-muted-foreground",
							children: s.label
						})]
					}, s.label);
				})
			})]
		})
	});
}
function Reveal({ children, delay = 0, y = 24, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
		className,
		initial: {
			opacity: 0,
			y
		},
		whileInView: {
			opacity: 1,
			y: 0
		},
		viewport: {
			once: true,
			margin: "-80px"
		},
		transition: {
			duration: .6,
			delay,
			ease: [
				.22,
				1,
				.36,
				1
			]
		},
		children
	});
}
function SectionHeading({ eyebrow, title, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
		className: "mb-10 flex flex-wrap items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-[0.22em] text-primary",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-3xl font-bold sm:text-4xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-1 w-20 rounded-full",
				style: { background: "var(--gradient-primary)" }
			})
		] }), action]
	});
}
var roles = [
	{
		icon: Landmark,
		title: "Dean, Innovation (CIIE)",
		detail: "Ravindra College of Engineering for Women — June 2025 to date."
	},
	{
		icon: Users,
		title: "Innovation Ambassador",
		detail: "Institution Innovation Council; 90+ IIC events coordinated across campuses."
	},
	{
		icon: FingerprintPattern,
		title: "Research Supervisor",
		detail: "33+ UG/PG scholars mentored in micro-electronics, Vedic mathematics and VLSI."
	}
];
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "about",
		className: "mx-auto max-w-6xl scroll-mt-24 px-5 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "About",
				title: "Academician, Researcher, Mentor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: roles.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .08,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-card h-full p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-11 w-11 place-items-center rounded-xl bg-accent text-accent-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(r.icon, { className: "h-5 w-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 text-base font-semibold",
								children: r.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: r.detail
							})
						]
					})
				}, r.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: .1,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card mt-4 flex flex-wrap items-center gap-x-8 gap-y-3 p-6 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4 text-primary" }),
								" ",
								profile.location
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["ORCID ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: profile.orcid
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Scopus ID ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: profile.scopus
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Vidwan ID ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: profile.vidwan
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["OpenAlex ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-foreground",
							children: profile.openalex
						})] })
					]
				})
			})
		]
	});
}
var icons = {
	Cpu,
	Sigma,
	AudioWaveform,
	BrainCircuit,
	HeartPulse,
	Lightbulb
};
function Research() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "research",
		className: "mx-auto max-w-6xl scroll-mt-24 px-5 py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Focus",
				title: "Research Areas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: researchAreas.map((area, i) => {
					const Icon = icons[area.icon] ?? Cpu;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * .07,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
							whileHover: { y: -6 },
							className: "surface-card group flex h-full flex-col p-8",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-6 w-6" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-bold leading-tight",
										children: area.title
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 flex-1 text-sm leading-relaxed text-muted-foreground",
									children: area.desc
								}),
								area.keywords && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 flex flex-wrap gap-2",
									children: area.keywords.map((kw) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-md bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground border border-border/50",
										children: kw
									}, kw))
								})
							]
						})
					}, area.title);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card h-full p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold uppercase tracking-[0.18em] text-primary",
						children: "Core Skills"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
							whileHover: { scale: 1.06 },
							className: "rounded-full border border-border bg-secondary px-3 py-1.5 text-xs font-medium text-secondary-foreground",
							children: s
						}, s))
					})]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: .1,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-card h-full p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-semibold uppercase tracking-[0.18em] text-primary",
							children: "Professional Memberships"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-2 text-sm text-muted-foreground",
							children: memberships.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" }), m]
							}, m))
						})]
					})
				})]
			})
		]
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var filters = [
	"All",
	"Journal",
	"Conference",
	"Book",
	"Chapter"
];
var yearFilters = [
	"All Years",
	"2026",
	"2025",
	"2024",
	"2023",
	"Previous"
];
function Publications() {
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [yearFilter, setYearFilter] = (0, import_react.useState)("All Years");
	const [q, setQ] = (0, import_react.useState)("");
	const list = (0, import_react.useMemo)(() => {
		const needle = q.trim().toLowerCase();
		return publications.filter((p) => filter === "All" ? true : p.type === filter).filter((p) => {
			if (yearFilter === "All Years") return true;
			if (yearFilter === "Previous") return p.year < 2023;
			return p.year.toString() === yearFilter;
		}).filter((p) => needle ? (p.title + p.venue + (p.index ?? "")).toLowerCase().includes(needle) : true).sort((a, b) => b.year - a.year);
	}, [
		filter,
		yearFilter,
		q
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "publications",
		className: "scroll-mt-24 bg-secondary/40 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Scholarship",
					title: "Publications & Books",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative w-full max-w-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Search titles, venues, indexing…",
							className: "bg-card pl-9"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: filters.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setFilter(f),
							className: `relative rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${filter === f ? "border-transparent text-primary-foreground" : "border-border bg-card text-muted-foreground hover:text-foreground"}`,
							children: [filter === f && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.span, {
								layoutId: "pub-filter",
								className: "absolute inset-0 rounded-full",
								style: { background: "var(--gradient-primary)" },
								transition: {
									type: "spring",
									stiffness: 380,
									damping: 32
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "relative",
								children: f
							})]
						}, f))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: yearFilters.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setYearFilter(y),
							className: `rounded-full border px-3 py-1 text-xs font-medium transition-colors ${yearFilter === y ? "border-primary bg-primary/10 text-primary" : "border-border bg-card text-muted-foreground hover:bg-secondary"}`,
							children: y
						}, y))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					layout: true,
					className: "grid gap-3 md:grid-cols-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
						mode: "popLayout",
						children: list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
							layout: true,
							initial: {
								opacity: 0,
								y: 16
							},
							animate: {
								opacity: 1,
								y: 0
							},
							exit: {
								opacity: 0,
								scale: .97
							},
							transition: { duration: .35 },
							className: "surface-card flex flex-col p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "rounded-md bg-accent px-2 py-0.5 text-accent-foreground",
											children: p.type
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground font-medium",
											children: p.year
										}),
										p.index && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-primary bg-primary/5 px-2 py-0.5 rounded-md",
											children: p.index
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 text-base font-bold leading-snug text-foreground/90",
									children: p.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted-foreground flex-1",
									children: p.venue
								}),
								p.link && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: p.link,
										target: "_blank",
										rel: "noreferrer",
										className: "inline-flex items-center justify-center gap-2 rounded-md bg-secondary px-4 py-2 text-xs font-semibold text-secondary-foreground transition-colors hover:bg-secondary/80 border border-border/50",
										children: ["View Publication ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3.5 w-3.5" })]
									})
								})
							]
						}, p.title))
					})
				}),
				list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-12 text-center text-sm text-muted-foreground",
					children: "No publications match that search."
				})
			]
		})
	});
}
function Patents() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "patents",
		className: "mx-auto max-w-6xl scroll-mt-24 px-5 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: "Intellectual Property",
			title: "Patents Filed & Granted"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 md:grid-cols-2 lg:grid-cols-3",
			children: patents.map((p, i) => {
				const isGranted = p.status.toLowerCase().includes("granted");
				const Icon = isGranted ? ShieldCheck : ShieldAlert;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .05,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						whileHover: { y: -4 },
						className: "surface-card flex h-full flex-col p-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `grid h-10 w-10 shrink-0 place-items-center rounded-xl ${isGranted ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${isGranted ? "bg-primary/15 text-primary" : "bg-secondary border border-border/50 text-muted-foreground"}`,
									children: p.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 text-sm font-bold leading-snug text-foreground/90 flex-1",
								children: p.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 flex items-center justify-between border-t border-border/50 pt-4 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "App No: "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: p.no
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-muted-foreground",
									children: p.year
								})]
							})
						]
					})
				}, p.no);
			})
		})]
	});
}
function Journey() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "journey",
		className: "scroll-mt-24 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "17+ Years",
				title: "Academic & Professional Journey"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: { scaleY: 0 },
					whileInView: { scaleY: 1 },
					viewport: { once: true },
					transition: {
						duration: 1.5,
						ease: "easeOut"
					},
					className: "absolute left-[27px] top-0 bottom-0 w-px origin-top sm:left-1/2 sm:-translate-x-1/2",
					style: { background: "var(--gradient-primary)" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-10",
					children: timeline.map((t, i) => {
						const isEven = i % 2 === 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i * .1,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `relative flex items-center gap-6 sm:gap-0 ${isEven ? "sm:flex-row" : "sm:flex-row-reverse"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "relative z-10 flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-border bg-card shadow-[var(--shadow-soft)] sm:absolute sm:left-1/2 sm:-translate-x-1/2",
									children: t.title.includes("Dean") || t.title.includes("Professor") || t.title.includes("Head") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-5 w-5 text-primary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-5 w-5 text-primary" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `flex-1 sm:w-1/2 ${isEven ? "sm:pr-14 sm:text-right" : "sm:pl-14 sm:text-left"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "surface-card p-6 relative inline-block w-full",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "inline-flex rounded-full bg-primary/10 px-3 py-1 text-sm font-bold text-primary mb-3",
												children: t.year
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-base font-bold text-foreground/90",
												children: t.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm leading-relaxed text-muted-foreground",
												children: t.detail
											})
										]
									})
								})]
							})
						}, t.year);
					})
				})]
			})]
		})
	});
}
var CarouselContext = import_react.createContext(null);
function useCarousel() {
	const context = import_react.useContext(CarouselContext);
	if (!context) throw new Error("useCarousel must be used within a <Carousel />");
	return context;
}
var Carousel = import_react.forwardRef(({ orientation = "horizontal", opts, setApi, plugins, className, children, ...props }, ref) => {
	const [carouselRef, api] = useEmblaCarousel({
		...opts,
		axis: orientation === "horizontal" ? "x" : "y"
	}, plugins);
	const [canScrollPrev, setCanScrollPrev] = import_react.useState(false);
	const [canScrollNext, setCanScrollNext] = import_react.useState(false);
	const onSelect = import_react.useCallback((api) => {
		if (!api) return;
		setCanScrollPrev(api.canScrollPrev());
		setCanScrollNext(api.canScrollNext());
	}, []);
	const scrollPrev = import_react.useCallback(() => {
		api?.scrollPrev();
	}, [api]);
	const scrollNext = import_react.useCallback(() => {
		api?.scrollNext();
	}, [api]);
	const handleKeyDown = import_react.useCallback((event) => {
		if (event.key === "ArrowLeft") {
			event.preventDefault();
			scrollPrev();
		} else if (event.key === "ArrowRight") {
			event.preventDefault();
			scrollNext();
		}
	}, [scrollPrev, scrollNext]);
	import_react.useEffect(() => {
		if (!api || !setApi) return;
		setApi(api);
	}, [api, setApi]);
	import_react.useEffect(() => {
		if (!api) return;
		onSelect(api);
		api.on("reInit", onSelect);
		api.on("select", onSelect);
		return () => {
			api?.off("select", onSelect);
		};
	}, [api, onSelect]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselContext.Provider, {
		value: {
			carouselRef,
			api,
			opts,
			orientation: orientation || (opts?.axis === "y" ? "vertical" : "horizontal"),
			scrollPrev,
			scrollNext,
			canScrollPrev,
			canScrollNext
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			onKeyDownCapture: handleKeyDown,
			className: cn("relative", className),
			role: "region",
			"aria-roledescription": "carousel",
			...props,
			children
		})
	});
});
Carousel.displayName = "Carousel";
var CarouselContent = import_react.forwardRef(({ className, ...props }, ref) => {
	const { carouselRef, orientation } = useCarousel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: carouselRef,
		className: "overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: cn("flex", orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col", className),
			...props
		})
	});
});
CarouselContent.displayName = "CarouselContent";
var CarouselItem = import_react.forwardRef(({ className, ...props }, ref) => {
	const { orientation } = useCarousel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		role: "group",
		"aria-roledescription": "slide",
		className: cn("min-w-0 shrink-0 grow-0 basis-full", orientation === "horizontal" ? "pl-4" : "pt-4", className),
		...props
	});
});
CarouselItem.displayName = "CarouselItem";
var CarouselPrevious = import_react.forwardRef(({ className, variant = "outline", size = "icon", ...props }, ref) => {
	const { orientation, scrollPrev, canScrollPrev } = useCarousel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		ref,
		variant,
		size,
		className: cn("absolute  h-8 w-8 rounded-full", orientation === "horizontal" ? "-left-12 top-1/2 -translate-y-1/2" : "-top-12 left-1/2 -translate-x-1/2 rotate-90", className),
		disabled: !canScrollPrev,
		onClick: scrollPrev,
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Previous slide"
		})]
	});
});
CarouselPrevious.displayName = "CarouselPrevious";
var CarouselNext = import_react.forwardRef(({ className, variant = "outline", size = "icon", ...props }, ref) => {
	const { orientation, scrollNext, canScrollNext } = useCarousel();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		ref,
		variant,
		size,
		className: cn("absolute h-8 w-8 rounded-full", orientation === "horizontal" ? "-right-12 top-1/2 -translate-y-1/2" : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90", className),
		disabled: !canScrollNext,
		onClick: scrollNext,
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Next slide"
		})]
	});
});
CarouselNext.displayName = "CarouselNext";
var slides = [
	{
		src: "/assets/g1-Bb44Kbzp.jpg",
		caption: "Innovation delegation visit to T-Works, Hyderabad"
	},
	{
		src: "/assets/g2-C3FUGWe2.jpg",
		caption: "Prototyping lab review — electric mobility platform"
	},
	{
		src: "/assets/g3-Bqg3eTfs.jpg",
		caption: "Industry–academia collaboration at T-Works"
	},
	{
		src: "/assets/g4-2m9UUS5M.jpg",
		caption: "Advanced fabrication facility walkthrough"
	},
	{
		src: "/assets/g6-tT2Ze3ju.jpg",
		caption: "National AgriTech Hackathon 2025"
	},
	{
		src: "/assets/amaravathispoken-DS5tHTpG.jpeg",
		caption: "Amaravathi Spoken Tutorial"
	},
	{
		src: "/assets/appeciation-Cz6rZnhv.jpeg",
		caption: "Appreciation and Recognition"
	},
	{
		src: "/assets/explain-8WN8lOb2.jpeg",
		caption: "Explaining Core Concepts"
	},
	{
		src: "/assets/judging-CkYZfxYJ.jpeg",
		caption: "Judging Innovation Hackathon"
	},
	{
		src: "/assets/research-D0jP4cmv.jpeg",
		caption: "Research Activities"
	},
	{
		src: "/assets/tablemeet-4nzr4gup.jpeg",
		caption: "Strategic Roundtable Meeting"
	},
	{
		src: "/assets/tp-7sCm3I_2.jpeg",
		caption: "Technical Presentation"
	}
];
function Gallery() {
	const [api, setApi] = (0, import_react.useState)();
	const [current, setCurrent] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!api) return;
		setCurrent(api.selectedScrollSnap());
		const onSelect = () => setCurrent(api.selectedScrollSnap());
		api.on("select", onSelect);
		const timer = setInterval(() => api.scrollNext(), 4200);
		return () => {
			clearInterval(timer);
			api.off("select", onSelect);
		};
	}, [api]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "gallery",
		className: "relative py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-3xl font-bold sm:text-4xl",
					children: ["Moments in ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-gradient",
						children: "Innovation"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-muted-foreground",
					children: "Glimpses from research visits, hackathons, industry collaborations and mentoring engagements."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: .1,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Carousel, {
						setApi,
						opts: {
							loop: true,
							align: "start"
						},
						className: "mt-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselContent, {
								className: "-ml-4",
								children: slides.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselItem, {
									className: "pl-4 sm:basis-1/2 lg:basis-1/3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.figure, {
										whileHover: { y: -6 },
										transition: {
											type: "spring",
											stiffness: 260,
											damping: 22
										},
										className: "group overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-soft)]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "aspect-[4/3] overflow-hidden bg-secondary/50 flex items-center justify-center p-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: s.src,
												alt: s.caption,
												loading: "lazy",
												className: "h-full w-full object-contain transition-transform duration-700 group-hover:scale-105"
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
											className: "px-4 py-3 text-xs leading-relaxed text-muted-foreground",
											children: s.caption
										})]
									})
								}, s.src))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselPrevious, { className: "-left-3 hidden sm:flex" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarouselNext, { className: "-right-3 hidden sm:flex" })
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 flex justify-center gap-2",
					children: slides.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": `Go to slide ${i + 1}`,
						onClick: () => api?.scrollTo(i),
						className: `h-1.5 rounded-full transition-all ${current === i ? "w-7 bg-primary" : "w-2.5 bg-border hover:bg-primary/40"}`
					}, s.src))
				})
			]
		})
	});
}
function Awards() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "awards",
		className: "mx-auto max-w-6xl scroll-mt-24 px-5 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: "Recognition",
			title: "Awards & Honours"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-6 md:grid-cols-2 lg:grid-cols-3",
			children: awards.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
				delay: i * .06,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					whileHover: {
						y: -6,
						rotate: -.4
					},
					className: "surface-card flex flex-col h-full p-8 relative overflow-hidden group",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-24 w-24 text-primary" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between relative z-10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "h-6 w-6" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-flex items-center rounded-full bg-secondary px-3 py-1 text-xs font-bold text-foreground border border-border/50 shadow-sm",
								children: a.year
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 relative z-10 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-base font-bold leading-snug text-foreground/90",
								children: a.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm font-medium text-muted-foreground",
								children: a.by
							})]
						})
					]
				})
			}, a.title))
		})]
	});
}
var collaborations = [
	{
		title: "Industry Projects & Consulting",
		icon: Handshake,
		desc: "Partnering with leading tech firms to bridge the gap between academic research and real-world semiconductor applications, optimizing architectures for commercial use."
	},
	{
		title: "Innovation Cell Leadership",
		icon: Target,
		desc: "Spearheading the Institution's Innovation Council (IIC) to foster a culture of entrepreneurship, hosting hackathons, and guiding early-stage tech incubations."
	},
	{
		title: "Student Product Mentoring",
		icon: Users,
		desc: "Mentoring engineering students through EPICS (Engineering Projects in Community Service) to develop sustainable, community-focused technological products."
	}
];
function Collaborations() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "collaborations",
		className: "mx-auto max-w-6xl scroll-mt-24 px-5 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: "Partnerships",
			title: "Research & Industry Collaboration"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-6 md:grid-cols-3",
			children: collaborations.map((collab, i) => {
				const Icon = collab.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .1,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						whileHover: { y: -6 },
						className: "surface-card flex h-full flex-col items-center text-center p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-6 grid h-16 w-16 place-items-center rounded-2xl bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-8 w-8" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-bold leading-snug",
								children: collab.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm leading-relaxed text-muted-foreground",
								children: collab.desc
							})
						]
					})
				}, collab.title);
			})
		})]
	});
}
var profiles = [
	{
		name: "Vidwan Profile",
		url: "https://vidwan.inflibnet.ac.in/profile/200676",
		icon: Library
	},
	{
		name: "ORCID ID",
		url: "https://orcid.org/0000-0002-6014-9844",
		icon: BookOpen
	},
	{
		name: "Scopus Author ID",
		url: "https://www.scopus.com/authid/detail.uri?authorId=57190013917",
		icon: ChartLine
	},
	{
		name: "OpenAlex",
		url: "https://openalex.org/A5049514785",
		icon: GraduationCap
	}
];
function AcademicProfiles() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "profiles",
		className: "mx-auto max-w-5xl scroll-mt-24 px-5 py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: "Identifiers",
			title: "Verified Academic Profiles"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap justify-center gap-4 mt-8",
			children: profiles.map((profile, i) => {
				const Icon = profile.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: i * .1,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.a, {
						whileHover: { scale: 1.05 },
						whileTap: { scale: .95 },
						href: profile.url,
						target: "_blank",
						rel: "noreferrer",
						className: "group flex items-center gap-3 rounded-full border border-border/50 bg-secondary px-6 py-3 shadow-[var(--shadow-soft)] transition-colors hover:border-primary/30 hover:bg-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-primary" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-foreground/90",
								children: profile.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-primary" })
						]
					})
				}, profile.name);
			})
		})]
	});
}
function CollaborateCTA() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "mx-auto max-w-4xl px-5 py-20 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				y: 20
			},
			whileInView: {
				opacity: 1,
				y: 0
			},
			viewport: { once: true },
			transition: { duration: .6 },
			className: "relative overflow-hidden rounded-3xl border border-primary/20 bg-card p-10 shadow-[var(--shadow-float)] sm:p-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 opacity-10",
				style: { background: "var(--gradient-primary)" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-3xl font-bold tracking-tight sm:text-4xl",
						children: ["Let's Collaborate on the ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gradient",
							children: "Future of Tech"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-4 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg",
						children: "Whether you're looking for R&D partnerships, institutional mentoring, or speaking engagements, I'm always open to driving meaningful innovation."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							className: "group rounded-full px-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#contact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "mr-2 h-4 w-4" }), "Reach Out Now"]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							variant: "outline",
							className: "group rounded-full px-8 bg-transparent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#research",
								children: ["View My Research", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" })]
							})
						})]
					})
				]
			})]
		})
	});
}
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
function Contact() {
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		email: "",
		message: ""
	});
	const [sending, setSending] = (0, import_react.useState)(false);
	const submit = (e) => {
		e.preventDefault();
		if (!form.name || !form.email || !form.message) {
			toast.error("Please fill in every field before sending.");
			return;
		}
		setSending(true);
		setTimeout(() => {
			setSending(false);
			setForm({
				name: "",
				email: "",
				message: ""
			});
			toast.success("Thanks! Your collaboration note has been noted.");
		}, 900);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contact",
		className: "scroll-mt-24 bg-secondary/40 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Get in touch",
				title: "Let's Collaborate"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[1fr_1.1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-card h-full p-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted-foreground",
							children: "Always open to research collaborations, innovation programmes, guest lectures and student mentoring initiatives."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: profile.linkedin,
									target: "_blank",
									rel: "noreferrer",
									className: "flex items-center gap-3 rounded-xl border border-border bg-card p-3 transition-colors hover:bg-accent",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, { className: "h-4 w-4 text-primary" }), " Dr. P. Bindu Swetha"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 rounded-xl border border-border bg-card p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4 text-primary" }),
										" ",
										profile.location
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 rounded-xl border border-border bg-card p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4 text-primary" }),
										" ORCID ",
										profile.orcid
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
							className: "mt-6 rounded-xl border border-border bg-card p-4 text-sm italic text-muted-foreground",
							children: "\"Learning is a continuous journey that should enrich professional growth and make a meaningful impact on society.\""
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
					delay: .1,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "surface-card h-full space-y-4 p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Your name",
									value: form.name,
									onChange: (e) => setForm({
										...form,
										name: e.target.value
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									placeholder: "Email address",
									value: form.email,
									onChange: (e) => setForm({
										...form,
										email: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 6,
								placeholder: "Tell me about your research idea or collaboration…",
								value: form.message,
								onChange: (e) => setForm({
									...form,
									message: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								whileTap: { scale: .98 },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									size: "lg",
									disabled: sending,
									className: "w-full",
									children: [sending ? "Sending…" : "Send Message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "ml-1 h-4 w-4" })]
								})
							})
						]
					})
				})]
			})]
		})
	});
}
function Index() {
	const { scrollYProgress } = useScroll();
	const progress = useSpring(scrollYProgress, {
		stiffness: 120,
		damping: 26,
		restDelta: .001
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				style: {
					scaleX: progress,
					background: "var(--gradient-primary)"
				},
				className: "fixed inset-x-0 top-0 z-[60] h-1 origin-left"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stats, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Research, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Publications, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Patents, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Journey, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Awards, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collaborations, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gallery, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AcademicProfiles, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollaborateCTA, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-border py-8 text-center text-xs text-muted-foreground",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" Dr. Pasuluri Bindu Swetha · Professor of ECE & Dean, Innovation"
				]
			})
		]
	});
}
//#endregion
export { Index as component };
