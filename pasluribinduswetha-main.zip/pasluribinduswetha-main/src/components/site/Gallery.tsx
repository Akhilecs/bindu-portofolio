import { useEffect, useState } from "react";
import { motion } from "motion/react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
  type CarouselApi,
} from "@/components/ui/carousel";
import { Reveal } from "@/components/site/Reveal";
import g1 from "@/assets/gallery/g1.jpg.asset.json";
import g2 from "@/assets/gallery/g2.jpg.asset.json";
import g3 from "@/assets/gallery/g3.jpg.asset.json";
import g4 from "@/assets/gallery/g4.jpg.asset.json";
import g5 from "@/assets/gallery/g5.jpg.asset.json";
import g6 from "@/assets/gallery/g6.jpg.asset.json";
import g7 from "@/assets/gallery/g7.jpg.asset.json";
import g8 from "@/assets/gallery/g8.jpg.asset.json";

const slides = [
  { src: g1.url, caption: "Innovation delegation visit to T-Works, Hyderabad" },
  { src: g2.url, caption: "Prototyping lab review — electric mobility platform" },
  { src: g3.url, caption: "Industry–academia collaboration at T-Works" },
  { src: g4.url, caption: "Advanced fabrication facility walkthrough" },
  { src: g5.url, caption: "Strategic innovation discussion with industry leadership" },
  { src: g6.url, caption: "National AgriTech Hackathon 2025, R.V.R. & J.C. College of Engineering" },
  { src: g7.url, caption: "Mentoring partnership meeting" },
  { src: g8.url, caption: "AgriTech Hackathon — innovation council initiative" },
];

export function Gallery() {
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (!api) return;
    setCurrent(api.selectedScrollSnap());
    const onSelect = () => setCurrent(api.selectedScrollSnap());
    api.on("select", onSelect);
    const timer = setInterval(() => api.scrollNext(), 4200);
    return () => {
      clearInterval(timer);
      api.off("select", onSelect);
    };
  }, [api]);

  return (
    <section id="gallery" className="relative py-20">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <h2 className="text-3xl font-bold sm:text-4xl">
            Moments in <span className="text-gradient">Innovation</span>
          </h2>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            Glimpses from research visits, hackathons, industry collaborations and mentoring engagements.
          </p>
        </Reveal>

        <Reveal delay={0.1}>
          <Carousel
            setApi={setApi}
            opts={{ loop: true, align: "start" }}
            className="mt-10"
          >
            <CarouselContent className="-ml-4">
              {slides.map((s, i) => (
                <CarouselItem key={s.src} className="pl-4 sm:basis-1/2 lg:basis-1/3">
                  <motion.figure
                    whileHover={{ y: -6 }}
                    transition={{ type: "spring", stiffness: 260, damping: 22 }}
                    className="group overflow-hidden rounded-2xl border border-border bg-card shadow-[var(--shadow-soft)]"
                  >
                    <div className="aspect-[4/3] overflow-hidden">
                      <img
                        src={s.src}
                        alt={s.caption}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                    </div>
                    <figcaption className="px-4 py-3 text-xs leading-relaxed text-muted-foreground">
                      {s.caption}
                    </figcaption>
                  </motion.figure>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="-left-3 hidden sm:flex" />
            <CarouselNext className="-right-3 hidden sm:flex" />
          </Carousel>
        </Reveal>

        <div className="mt-6 flex justify-center gap-2">
          {slides.map((s, i) => (
            <button
              key={s.src}
              aria-label={`Go to slide ${i + 1}`}
              onClick={() => api?.scrollTo(i)}
              className={`h-1.5 rounded-full transition-all ${
                current === i ? "w-7 bg-primary" : "w-2.5 bg-border hover:bg-primary/40"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
