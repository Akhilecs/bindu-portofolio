import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ChevronDown, ShieldCheck } from "lucide-react";
import { patents } from "@/data/profile";
import { Reveal, SectionHeading } from "./Reveal";

export function Patents() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="patents" className="mx-auto max-w-6xl scroll-mt-24 px-5 py-16">
      <SectionHeading eyebrow="Intellectual Property" title="Patents Filed & Granted" />
      <div className="grid gap-3">
        {patents.map((p, i) => (
          <Reveal key={p.no} delay={i * 0.03}>
            <div className="surface-card overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center gap-4 p-5 text-left"
              >
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent text-accent-foreground">
                  <ShieldCheck className="h-4 w-4" />
                </span>
                <span className="flex-1">
                  <span className="block text-sm font-semibold">{p.title}</span>
                  <span className="mt-0.5 block text-xs text-muted-foreground">
                    {p.status} · {p.year}
                  </span>
                </span>
                <motion.span animate={{ rotate: open === i ? 180 : 0 }}>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </motion.span>
              </button>
              <AnimatePresence initial={false}>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="border-t border-border px-5 py-4 text-xs text-muted-foreground">
                      Application number <span className="font-semibold text-foreground">{p.no}</span> ·
                      Status: <span className="font-semibold text-primary">{p.status}</span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
