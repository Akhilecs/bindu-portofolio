import { motion } from "motion/react";
import { Trophy } from "lucide-react";
import { awards } from "@/data/profile";
import { Reveal, SectionHeading } from "./Reveal";

export function Awards() {
  return (
    <section id="awards" className="mx-auto max-w-6xl scroll-mt-24 px-5 py-16">
      <SectionHeading eyebrow="Recognition" title="Awards & Honours" />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {awards.map((a, i) => (
          <Reveal key={a.title} delay={i * 0.06}>
            <motion.div whileHover={{ y: -6, rotate: -0.4 }} className="surface-card h-full p-6">
              <div className="flex items-start justify-between">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-accent text-accent-foreground">
                  <Trophy className="h-5 w-5" />
                </span>
                <span className="text-xs font-bold text-primary">{a.year}</span>
              </div>
              <h3 className="mt-4 text-sm font-semibold leading-snug">{a.title}</h3>
              <p className="mt-1.5 text-xs text-muted-foreground">{a.by}</p>
            </motion.div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
