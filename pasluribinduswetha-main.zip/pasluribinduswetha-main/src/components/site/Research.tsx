import { motion } from "motion/react";
import {
  AudioWaveform,
  BrainCircuit,
  Cpu,
  HeartPulse,
  Lightbulb,
  Sigma,
  type LucideIcon,
} from "lucide-react";
import { researchAreas, skills, memberships } from "@/data/profile";
import { Reveal, SectionHeading } from "./Reveal";

const icons: Record<string, LucideIcon> = {
  Cpu,
  Sigma,
  AudioWaveform,
  BrainCircuit,
  HeartPulse,
  Lightbulb,
};

export function Research() {
  return (
    <section id="research" className="mx-auto max-w-6xl scroll-mt-24 px-5 py-16">
      <SectionHeading eyebrow="Focus" title="Research Areas" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {researchAreas.map((area, i) => {
          const Icon = icons[area.icon] ?? Cpu;
          return (
            <Reveal key={area.title} delay={i * 0.07}>
              <motion.article
                whileHover={{ y: -6 }}
                className="surface-card group h-full p-6"
              >
                <span className="grid h-12 w-12 place-items-center rounded-xl bg-accent text-accent-foreground transition-transform duration-300 group-hover:scale-110 group-hover:rotate-6">
                  <Icon className="h-5 w-5" />
                </span>
                <h3 className="mt-4 text-lg font-semibold">{area.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{area.desc}</p>
              </motion.article>
            </Reveal>
          );
        })}
      </div>

      <div className="mt-10 grid gap-4 lg:grid-cols-2">
        <Reveal>
          <div className="surface-card h-full p-6">
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-primary">Core Skills</h3>
            <div className="mt-4 flex flex-wrap gap-2">
              {skills.map((s) => (
                <motion.span
                  key={s}
                  whileHover={{ scale: 1.06 }}
                  className="rounded-full border border-border bg-secondary px-3 py-1.5 text-xs font-medium text-secondary-foreground"
                >
                  {s}
                </motion.span>
              ))}
            </div>
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <div className="surface-card h-full p-6">
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-primary">
              Professional Memberships
            </h3>
            <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
              {memberships.map((m) => (
                <li key={m} className="flex gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  {m}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
