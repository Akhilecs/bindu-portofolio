import { motion } from "motion/react";
import { GraduationCap } from "lucide-react";
import { timeline } from "@/data/profile";
import { Reveal, SectionHeading } from "./Reveal";

export function Journey() {
  return (
    <section id="journey" className="scroll-mt-24 bg-secondary/40 py-16">
      <div className="mx-auto max-w-6xl px-5">
        <SectionHeading eyebrow="17+ Years" title="Academic & Professional Journey" />
        <div className="relative">
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1.1, ease: "easeOut" }}
            className="absolute left-0 top-6 hidden h-px w-full origin-left lg:block"
            style={{ background: "var(--gradient-primary)" }}
          />
          <div className="grid gap-6 lg:grid-cols-5">
            {timeline.map((t, i) => (
              <Reveal key={t.year} delay={i * 0.1}>
                <div className="relative">
                  <div className="mb-4 hidden lg:block">
                    <span className="grid h-12 w-12 place-items-center rounded-full border border-border bg-card shadow-[var(--shadow-soft)]">
                      <GraduationCap className="h-5 w-5 text-primary" />
                    </span>
                  </div>
                  <p className="text-sm font-bold text-primary">{t.year}</p>
                  <h3 className="mt-1 text-sm font-semibold">{t.title}</h3>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{t.detail}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
