import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ExternalLink, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { publications, type Publication } from "@/data/profile";
import { SectionHeading } from "./Reveal";

const filters = ["All", "Journal", "Conference", "Book", "Chapter"] as const;

export function Publications() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");
  const [q, setQ] = useState("");

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return publications
      .filter((p: Publication) => (filter === "All" ? true : p.type === filter))
      .filter((p) =>
        needle ? (p.title + p.venue + (p.index ?? "")).toLowerCase().includes(needle) : true,
      )
      .sort((a, b) => b.year - a.year);
  }, [filter, q]);

  return (
    <section id="publications" className="scroll-mt-24 bg-secondary/40 py-16">
      <div className="mx-auto max-w-6xl px-5">
        <SectionHeading
          eyebrow="Scholarship"
          title="Publications & Books"
          action={
            <div className="relative w-full max-w-xs">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search titles, venues, indexing…"
                className="bg-card pl-9"
              />
            </div>
          }
        />

        <div className="mb-6 flex flex-wrap gap-2">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`relative rounded-full border px-4 py-1.5 text-sm font-medium transition-colors ${
                filter === f
                  ? "border-transparent text-primary-foreground"
                  : "border-border bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {filter === f && (
                <motion.span
                  layoutId="pub-filter"
                  className="absolute inset-0 rounded-full"
                  style={{ background: "var(--gradient-primary)" }}
                  transition={{ type: "spring", stiffness: 380, damping: 32 }}
                />
              )}
              <span className="relative">{f}</span>
            </button>
          ))}
        </div>

        <motion.div layout className="grid gap-3 md:grid-cols-2">
          <AnimatePresence mode="popLayout">
            {list.map((p) => (
              <motion.article
                layout
                key={p.title}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.97 }}
                transition={{ duration: 0.35 }}
                className="surface-card p-5"
              >
                <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider">
                  <span className="rounded-md bg-accent px-2 py-0.5 text-accent-foreground">{p.type}</span>
                  <span className="text-muted-foreground">{p.year}</span>
                  {p.index && <span className="text-primary">{p.index}</span>}
                </div>
                <h3 className="mt-3 text-sm font-semibold leading-snug">{p.title}</h3>
                <p className="mt-1.5 text-xs text-muted-foreground">{p.venue}</p>
                {p.link && (
                  <a
                    href={p.link}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
                  >
                    Read paper <ExternalLink className="h-3 w-3" />
                  </a>
                )}
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>

        {list.length === 0 && (
          <p className="py-12 text-center text-sm text-muted-foreground">No publications match that search.</p>
        )}
      </div>
    </section>
  );
}
